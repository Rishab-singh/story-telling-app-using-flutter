import 'package:flutter/material.dart';
import 'story_detail_screen.dart';

class StoryListScreen extends StatelessWidget {
  final String category;
  final List<Map<String, String>> stories;

  const StoryListScreen({required this.category, required this.stories});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('$category Stories'),
      ),
      body: ListView.builder(
        itemCount: stories.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(stories[index]['title']!),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => StoryDetailScreen(
                    title: stories[index]['title']!,
                    content: stories[index]['content']!,
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
