final List<Map<String, String>> adventureStories = [
  {
    'title': 'The Mountain Adventure',
    'content': '''
Amelia grew up in a small town at the base of the Northern Peaks, her childhood filled with tales of her grandfather’s daring expeditions. Her favorite memories were of sitting by the fireplace, listening to him recount stories of ancient trails, lost civilizations, and hidden treasures. But one tale stood out—the story of the Hidden Valley, a place he had sought his entire life but never found.

One rainy afternoon, while sorting through the old attic of her family’s home, Amelia stumbled upon a yellowed map tucked inside a leather-bound journal. The map was crudely drawn but detailed enough to spark her curiosity. Accompanying it were her grandfather’s notes, filled with sketches, observations, and cryptic warnings: "Beware the whispers of the wind" and "The greatest treasure requires the greatest resolve."

Heart racing, Amelia decided to follow in her grandfather's footsteps. With a backpack filled with essentials—sturdy boots, a compass, and her grandfather’s journal—she embarked on the journey. The Northern Peaks were as majestic as they were unforgiving. Towering cliffs loomed above her, and roaring rivers threatened her path. Yet, her grandfather's words echoed in her mind: "Courage is the key to all discovery."

On the second day of her trek, she encountered her first challenge: a narrow ledge that clung precariously to a cliffside. The path was slick with morning dew, and below, jagged rocks waited ominously. Taking a deep breath, Amelia steadied herself and pressed on. Her determination carried her through the treacherous path, though her heart pounded with every step.

By the third day, Amelia reached a dense forest marked on the map. The air grew colder, and an eerie silence enveloped her. Following the map’s instructions, she found a hidden cave near a waterfall. Inside, the walls were covered with ancient carvings depicting a serene valley filled with radiant light and abundant wildlife. A message was etched into the stone in an archaic script, which her grandfather had deciphered in his journal:
"The valley lies within the heart of those who endure."

As she emerged from the cave, Amelia felt a strange energy guiding her. She climbed higher, the altitude making her lungs burn. The wind howled, carrying faint whispers that seemed to urge her forward. Finally, she reached the summit, where the terrain abruptly leveled out.

Before her lay the Hidden Valley—a paradise untouched by time. Towering trees with golden leaves swayed gently in the wind, and vibrant flowers carpeted the ground. A sparkling stream wound its way through the valley, its waters shimmering in the sunlight. In the center stood an ancient oak tree with sprawling roots that wrapped around a rusted chest.

With trembling hands, Amelia opened the chest, revealing its contents: ancient coins, precious gemstones, and yet another note. This one was written in her grandfather’s hand:
"Amelia, if you are reading this, you’ve found the treasure I spent my life searching for. But the true treasure isn’t gold or jewels—it’s the courage to follow your dreams, no matter the obstacles. Take this as a reminder that adventure lives in the hearts of those who dare to seek it."

Tears welled up in her eyes. She realized the journey had been more than an expedition—it was a bridge connecting her to her grandfather's spirit. Packing a few coins as keepsakes, Amelia left the rest of the treasure undisturbed, a tribute to the legacy of her grandfather.

As she descended the mountains, Amelia felt a newfound strength within her. The Hidden Valley had not only gifted her treasures but had awakened an adventurer’s heart. From that day forward, she vowed to share her story, inspiring others to seek their own adventures and believe in the magic of exploration.'''
  },
  {
    'title': 'Lost in the Jungle',
    'content': '''
Ethan was part of an environmental research team studying the Amazon rainforest. Their mission was to document the effects of deforestation on local ecosystems and find ways to mitigate the damage. Their helicopter, overloaded with equipment and samples, malfunctioned during a violent storm and crashed deep in the jungle. Ethan woke up disoriented, surrounded by towering trees and the cacophony of wildlife. He quickly realized he was the sole survivor of the crash.

The jungle was both mesmerizing and terrifying. The bright colors of exotic birds and flowers captivated him, but every shadow seemed to hide a potential danger—venomous snakes slithered silently across his path, jaguars prowled nearby, and quicksand waited for the unwary. Ethan's knowledge of survival techniques, gleaned from years of research, became his only weapon against the jungle’s hostility.

His first priority was finding water. Ethan followed the sounds of a distant stream and used his filtration kit to purify enough to sustain him for the next few days. He fashioned a makeshift shelter from large leaves and vines to protect himself from the rain and predatory animals at night.

One evening, while foraging for food, Ethan stumbled upon a discovery that filled him with awe and unease—a massive ancient temple, hidden beneath layers of vines and moss. The temple’s intricate carvings depicted a story of harmony between humans and the jungle, a sacred bond that ensured the survival of both. Among the carvings, he saw warnings: "Those who exploit the jungle will face its wrath."

Curiosity outweighed his fear, and Ethan ventured inside. The air was thick and damp, and the walls seemed alive with the movements of countless insects. Deep within the temple, he discovered a series of chambers containing artifacts and inscriptions. One chamber held a mosaic of a tree whose roots spread across the earth, symbolizing the interconnectedness of life. The chamber also contained seeds stored in clay jars—seeds of trees that had long been extinct due to deforestation.

As days turned into weeks, Ethan's understanding of the jungle evolved. He began to see it not as an enemy, but as a living, breathing system that required respect and balance. He studied the behaviors of animals and plants, learning to coexist with the jungle’s rhythms. The longer he stayed, the more he realized how deeply humanity had underestimated the importance of these ecosystems.

After nearly a month, Ethan was finally rescued by a search team. He emerged from the jungle changed, not just physically, but spiritually. He returned to civilization with a renewed sense of purpose and a journal filled with insights and drawings of the temple and its messages.

Ethan dedicated the rest of his life to conservation efforts. He published a book recounting his survival and the lessons he learned from the jungle. His advocacy led to the preservation of thousands of acres of rainforest and inspired others to respect the natural world.

Even years later, as an older man, Ethan could still close his eyes and hear the jungle—the rustling of leaves, the calls of birds, and the whispers of the ancient temple reminding him of the balance that binds all living things.
'''
  },
];

final List<Map<String, String>> romanceStories = [
  {
    'title': 'The Café Encounter',
    'content': '''
Lila was a writer struggling with her debut novel. Each morning, she found solace in a small café on Pine Street, a place where the aroma of freshly brewed coffee and the soft hum of conversations fueled her creativity. It was her safe haven, a world apart from the pressures of looming deadlines and persistent self-doubt.

One particularly rainy day, as the droplets cascaded down the café's large glass windows, Lila sat by her favorite corner table, staring blankly at the screen of her laptop. The words wouldn't come. Frustrated, she closed her laptop and reached for her notebook to sketch out ideas. That’s when she noticed him—a man sitting by the window, his gaze alternating between his sketchpad and... her.

The man, engrossed in his work, hadn’t noticed her noticing him. Curious and a little flustered, Lila gathered her courage and approached him.

“Hi,” she said, her voice tinged with both nervousness and curiosity. “I couldn’t help but notice you’ve been sketching. Is that... me?”

Startled, the man looked up, his face breaking into a warm smile. “I—uh, yes. I’m sorry if that’s weird. I’m Aaron,” he replied, holding up the sketchpad. The drawing was a beautiful charcoal rendering of Lila, her thoughtful expression captured perfectly.

Lila’s initial surprise gave way to admiration. “That’s incredible. You made me look so much more... composed than I feel,” she said with a laugh. Aaron chuckled and gestured toward the empty seat across from him. “I find inspiration in people’s stories. Would you like to tell me yours?”

What began as a brief introduction turned into a long, animated conversation. They talked about everything: Lila’s struggles as a writer, Aaron’s passion for art, their favorite books, and the little quirks of the café they both frequented. Aaron revealed that he often came to the café not just to sketch, but to observe people and imagine the worlds they carried within them.

Over the next few weeks, Aaron and Lila became inseparable. Each day, they found themselves drawn to the same corner of the café, sharing their ideas and dreams. Aaron’s sketches began to inspire Lila’s writing, and Lila’s stories added depth to Aaron’s artwork. Slowly, their collaboration became a ritual, and the café turned into their creative haven.

One afternoon, as the café buzzed with its usual patrons, Aaron slid a small sketchbook across the table. Inside were dozens of drawings—scenes from Lila’s novel brought to life through his art. Lila’s breath caught in her throat as she turned the pages.

“I want to help you finish your story,” Aaron said, his voice steady but hopeful. “Not just as an artist, but... as someone who believes in you.”

Lila was overwhelmed. No one had ever supported her dreams with such sincerity. “Aaron,” she began, her voice trembling, “you already have. More than you know.”

Months later, Lila’s debut novel was published, its cover adorned with Aaron’s artwork. The dedication read: "To the artist who sketched my dreams into reality." At the book’s launch party, held at the café where it all began, Lila stood before a crowd of readers and thanked Aaron for being her muse, her partner, and her greatest source of inspiration.

As the evening drew to a close, Aaron handed Lila a small gift—a painting of the café, with two figures seated by the window. “Our story,” he said simply. Lila looked at him, tears in her eyes, and whispered, “And it’s just the beginning.”


'''
  },
  {
    'title': 'A Love Across Oceans',
    'content': '''
Mia and Liam had always shared a love for adventure, a passion for exploring the world and discovering new places. They met during an international student exchange program, a serendipitous encounter that changed both of their lives forever. The program brought them together in a vibrant city far from their homes, and it didn’t take long for them to form an inseparable bond.

Their time together was spent exploring the city’s winding streets, tasting its exotic foods, and sharing stories of their cultures. But their favorite place was always the same: the seaside pier at sunset. Each evening, they would walk down to the water's edge, watching the sun dip below the horizon as the waves lapped gently at their feet. In those moments, time seemed to stand still. The world was theirs, and all that mattered was the connection they shared.

But as the program neared its end, reality set in. Mia, from the quiet towns of the English countryside, and Liam, a city boy from Australia, knew that their time together was limited. The looming distance between them felt insurmountable, yet neither of them could deny the bond they had formed. They promised to keep in touch, determined to keep their relationship alive despite the miles that would soon separate them.

Back in their respective countries, the challenges of long-distance love quickly became apparent. Mia’s final year at university was stressful, with endless assignments and exams. Liam, who had returned to Australia, found himself immersed in a demanding job at a tech firm. Despite their busy lives, they held onto their love through late-night video calls, handwritten letters, and surprise care packages filled with little trinkets from their respective countries.

Yet, the distance began to take its toll. Mia started to doubt herself. She found herself sinking into the pressure of her studies, her energy drained by the growing distance between her and Liam. She questioned whether they could really make it work when so much of their lives had to be lived apart. Meanwhile, Liam was faced with mounting pressure at work. The long hours, the responsibilities, and the distance from Mia left him feeling disconnected, despite his best efforts to maintain their bond.

One evening, months after their last visit, Mia sat alone at the pier by the sea. The familiar sight of the ocean was comforting, but her heart felt heavy with doubt. As the sun set, casting a warm glow across the horizon, she let out a soft sigh. She wasn’t sure how much longer she could keep going like this—feeling so far away from the person she loved most in the world.

Suddenly, she heard footsteps behind her. She turned, and there, standing in the fading light, was Liam. He was holding a bouquet of her favorite flowers, a mix of daisies and sunflowers, and his eyes were filled with a mix of love and determination.

“I couldn’t stay away,” Liam said, his voice thick with emotion. “I know it hasn’t been easy, but I couldn’t let this—let us—fade away.”

Mia stood up, her heart racing, as Liam continued. “I’ve transferred my job to your city. I’m here to stay. I want to build a life with you, Mia. A life that isn’t defined by distance.”

Tears welled up in Mia’s eyes. It felt like a dream—an impossible dream—that Liam had made a reality. She rushed into his arms, overwhelmed by the love and relief she felt.

But Liam wasn’t finished yet. As they pulled apart, he smiled softly and got down on one knee, holding out a small velvet box. “Mia,” he began, his voice barely a whisper, “will you marry me?”

Mia’s heart skipped a beat. This was the moment she had longed for but never imagined could come true. The miles between them, the challenges, the doubts—they all seemed insignificant now. All that mattered was the man standing before her, offering her a future, a life together.

“Yes,” she whispered, her voice shaking. “Yes, I will marry you.”

Liam stood up, pulling her into a deep, passionate kiss. The sun had fully set, but their world was just beginning, as was their story.

In the years that followed, Mia and Liam’s love only grew stronger. They traveled the world together, creating memories and exploring new horizons, but they always returned to the pier. It became their symbol of enduring love—where they had first met, where they had shared their dreams, and where they had vowed to never let go.

They knew that life would throw challenges their way, but they also knew that as long as they were together, no ocean, no distance, could ever come between them.'''
  },
];

final List<Map<String, String>> horrorStories = [
  {
    'title': 'The Haunted Manor',
    'content': '''
    Sophia was a renowned paranormal investigator, known for her rational approach to the supernatural. Over the years, she had debunked countless ghost stories, attributing them to natural causes—drafts, creaking floorboards, and overactive imaginations. But there was one story she couldn’t ignore. It was the legend of Blackwood Manor, an ancient estate that had stood for centuries on the outskirts of the small town of Ravenhill. The locals whispered of its dark history—of strange disappearances, eerie lights flickering in the windows on moonless nights, and the occasional shrill scream that echoed through the fog.

The manor had been abandoned for decades, its once grand structure now crumbling and covered in ivy. But rumors persisted that something—someone—was still lurking inside. It was the perfect opportunity for Sophia to make a name for herself, to finally put an end to the wild tales that had haunted the town for years.

Equipped with her camera, EMF reader, infrared thermometer, and a variety of other tools, Sophia made her way to the manor one stormy evening. The sky was thick with dark clouds, and the air was thick with the scent of rain and decay. As she approached the iron gates, which stood open as if welcoming her, she couldn't help but feel a cold chill creep down her spine. She ignored the sensation—after all, it was just her mind playing tricks on her. She had been in many supposedly haunted places before, and nothing had ever fazed her.

The manor stood before her, its looming silhouette bathed in the pale light of a flickering streetlamp. The building was massive, with towering spires and broken windows that seemed to watch her as she made her way up the cracked stone path. The door creaked open with little resistance, as though it had been waiting for her arrival.

Inside, the manor was shrouded in a heavy darkness, save for the dim light of her flashlight cutting through the gloom. Dust clung to the air, and the faint smell of mildew lingered. As she stepped inside, the floorboards groaned under her weight. She quickly set up her equipment, placing her camera on a tripod, and began walking through the manor’s expansive rooms.

It didn’t take long before strange things began to happen. Shadows flickered across the walls, moving in ways that defied logic. The air grew colder with every passing minute, and a deep, unsettling silence filled the house, broken only by the occasional creak of wood. As she explored the halls, she came across an old portrait hanging crookedly on the wall. The woman in the painting was beautiful, but her eyes seemed to follow Sophia as she passed.

Sophia’s heart rate quickened, but she was determined to push forward. She entered what appeared to be the drawing room, its walls lined with decaying bookshelves and covered in thick layers of dust. At the far end of the room, she saw a door that led to the basement. A faint sound—a whisper—seemed to drift from behind it. It was almost imperceptible, but it was there.

Against her better judgment, Sophia walked towards the door and opened it.

The stairs leading down into the basement were steep and narrow, the air thick with an oppressive atmosphere. As she descended, the temperature dropped even further, and the whispers grew louder. When she reached the bottom, she was met with an overwhelming sense of dread. The basement was filled with old furniture covered in sheets, and at the far corner of the room stood an ancient, ornate mirror framed in gold.

The mirror was unsettling. Unlike the rest of the room, it was completely clean, its surface free of dust. The light from Sophia’s flashlight flickered as she approached it, casting strange shadows on the walls. She looked into the mirror, expecting to see only her own reflection, but what she saw was far more chilling.

The reflection staring back at her was not her own.

It was a woman, pale with hollow eyes, her long dark hair matted with something unidentifiable. The woman’s lips moved, forming words that Sophia couldn’t hear, but somehow, she understood. “You shouldn’t be here…”

Suddenly, the room grew colder, and the whispers turned to a loud, anguished wail. The woman in the mirror’s reflection reached out, her hands pressing against the glass as if trying to escape. Sophia staggered backward, her heart pounding in her chest.

Before she could react, the basement door slammed shut, trapping her inside. The temperature plummeted, and the whispers became deafening. She scrambled for the door, her hands trembling as she tried to open it, but it was locked tight.

Panic surged through her as she turned back toward the mirror, only to find the woman’s reflection now staring at her, her eyes filled with anger. The glass rippled as if it were water, and the woman began to climb through, her hand reaching for Sophia’s throat.

Sophia screamed, throwing herself backward, but there was no escape. The mirror shattered with a deafening crash, and the woman emerged from the broken glass, her cold fingers wrapping around Sophia’s neck.

In the chaos, Sophia’s camera fell to the floor, capturing one final image—a picture of the woman’s face, twisted in fury. The screen went black, and the camera’s memory card was found months later in the wreckage of the manor.

To this day, no one has been able to uncover what happened to Sophia. Some say she was taken by the vengeful spirit of Eliza Blackwood, the last resident of the manor, whose tragic fate had bound her to the house for eternity. Others believe that the manor itself has a life of its own—one that hungers for souls to join its cursed history.

The mansion still stands, its decaying walls and broken windows an eerie reminder that some places are better left undisturbed. Visitors to Ravenhill still claim to hear the whispers of the woman in the mirror, calling out to anyone brave—or foolish—enough to enter.
'''
  },
  {
    'title': 'The Mirror’s Curse',
    'content': '''
Jake had always been fascinated by antiques, drawn to the beauty and mystery of objects that had withstood the test of time. His small apartment was filled with an eclectic collection—old books, tarnished silverware, weathered paintings, and trinkets from distant places. But his latest find was unlike any other. He had stumbled upon it in a dusty corner of an estate sale, hidden beneath a thick velvet cloth—an ornate, gilded mirror. It was large and imposing, its frame intricately carved with floral patterns and delicate, swirling designs that shimmered even in the dim light of the room.

There was something about the mirror that caught his attention immediately. Perhaps it was the way the light seemed to reflect from it, casting unusual patterns across the room. The moment he laid eyes on it, Jake felt a strange pull, an unexplainable desire to take it home. The seller, an elderly woman who had watched him with an almost nervous intensity, told him it had been in her family for generations. “It’s not just a mirror,” she warned, her voice trembling. “There’s something... odd about it. It’s been in our family for years, but no one’s ever looked into it for long. You’ll understand soon enough.”

Jake, ever the skeptic, dismissed her words as superstition, believing that this was just another old, haunted object that people had turned into a myth. The price was too good to resist, and so he bought it. The woman’s words lingered in his mind, but he shrugged them off. After all, he had dealt with countless antiques, and nothing ever seemed out of the ordinary.

Once home, Jake placed the mirror on the wall opposite his couch. Its reflective surface was pristine, offering a perfect reflection of the room—except for one odd detail. When he gazed into it, he noticed a strange sensation. It wasn’t the usual reflection of himself; instead, he felt as though someone was watching him from inside the glass. He shook off the unease, convincing himself it was merely the result of an overactive imagination.

That night, as he settled into bed, he turned off the lights, but something compelled him to glance at the mirror once more. The room was dark, the only light coming from the moon filtering through the window. Yet, the mirror gleamed softly, as though illuminated by some unseen source. Jake felt a chill, but it wasn’t the cold air from the open window—it was an inexplicable, creeping sensation that started at the back of his neck and spread through his limbs. His gaze was drawn back to the mirror.

For the first time, Jake saw something that made his heart race in his chest. A shadow moved within the reflection, standing just behind him. He spun around, but there was nothing in the room. The air seemed to grow thick, and the faintest sound echoed in his ears—a whisper, barely audible, but unmistakable. He stepped forward toward the mirror, his pulse quickening, trying to dismiss the fear that was slowly creeping up on him.

But as his fingers brushed against the cold surface of the mirror, everything changed.

The reflection in the mirror rippled, as if disturbed by an unseen hand. Jake’s breath caught in his throat as he saw something terrifying—a dark figure, gaunt and skeletal, with hollow, empty eyes staring back at him. The figure’s lips parted, its mouth stretching wide as if to speak. But no words came—just an overwhelming sense of dread that suffocated the room.

Jake stumbled back, his heart pounding in his chest, but the figure in the mirror didn’t disappear. It stepped forward, pushing through the glass with unnatural ease. The figure was no longer confined to the reflection. It was in the room with him.

He turned to flee, but his legs felt heavy, his body refusing to move as he found himself rooted in place. The figure’s hand reached out from the mirror, its long fingers curling toward him, cold as ice. “Thank you for setting me free,” it whispered, its voice hollow and distant.

Jake screamed, but no sound left his mouth. His reflection in the mirror began to move without him, as though the figure had taken control of his very being. His own face twisted into a grotesque version of itself, eyes wide in horror, yet unable to scream for help. It was as if the reflection had become his true self, and he—Jake—was the one trapped inside.

Desperate, Jake grabbed a nearby chair and swung it at the mirror, shattering the glass into a thousand sharp fragments. The room was filled with the sound of the glass breaking, but as the shards fell to the floor, something chilling happened. From the broken pieces, the reflection of the figure remained. It didn’t matter that the mirror was gone—the figure was still there, smiling darkly at him through the shards.

Jake dropped to his knees, his vision blurring as his mind teetered on the edge of madness. He could feel the cold hands of the figure closing in on him, its presence filling every corner of the room. The last thing he saw before everything went black was the figure’s face, no longer in the shards of glass but in his own reflection, staring back at him with empty eyes.

The next day, Jake’s body was found, lifeless, on the floor. His face was frozen in terror, as if he had seen something unimaginable just before his death. The police were baffled, unable to explain the strange circumstances of his demise. The mirror was gone, shattered beyond repair, and there were no signs of any struggle.

However, a strange thing was noticed later—on the back of the broken pieces of the mirror, there was a faint inscription, etched into the glass. It read: “A soul is traded to set another free.”

The mirror was no longer in Jake’s apartment, but some say it’s still out there—waiting to claim its next victim. Those who claim to have seen it report strange occurrences, feeling as though they are being watched from the reflection, or hearing whispers in the dead of night. And the most chilling part of all? They say the figure in the mirror is still looking for a new host—a new soul to take its place.

No one knows where the cursed mirror is now, but one thing is certain: if you find it, don’t look too long into its depths. Because once you do, you may never escape its gaze.
'''
  },
];
