import 'package:flutter/material.dart';
import 'home_screen.dart';

void main() => runApp(StoryApp());

class StoryApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Story App',
      theme: ThemeData.dark(),
      home: HomeScreen(),
    );
  }
}
