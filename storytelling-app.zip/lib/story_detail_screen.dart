import 'package:flutter/material.dart';

class StoryDetailScreen extends StatelessWidget {
  final String title;
  final String content;

  const StoryDetailScreen({required this.title, required this.content});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(title),
      ),
      body: Stack(
        children: [
          SingleChildScrollView(
            padding: const EdgeInsets.all(16.0),
            child: Text(
              content,
              style: const TextStyle(fontSize: 18, height: 1.5),
            ),
          ),
          Positioned(
            right: 16,
            bottom: 16,
            child: FloatingActionButton(
              onPressed: () {},
              child: const Icon(Icons.bookmark),
            ),
          ),
        ],
      ),
    );
  }
}
